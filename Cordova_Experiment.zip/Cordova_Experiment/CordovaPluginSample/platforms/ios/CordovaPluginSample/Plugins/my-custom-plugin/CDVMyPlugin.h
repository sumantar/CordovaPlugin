#import <Cordova/CDV.h>

@interface CDVMyPlugin : CDVPlugin

- (void) greet:(CDVInvokedUrlCommand*)command;

@end