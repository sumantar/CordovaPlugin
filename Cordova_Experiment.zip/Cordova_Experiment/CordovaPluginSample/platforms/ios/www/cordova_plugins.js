cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/my-custom-plugin/www/myplugin.js",
        "id": "my-custom-plugin.myplugin",
        "clobbers": [
            "myplugin"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.0.0",
    "my-custom-plugin": "0.0.1"
}
// BOTTOM OF METADATA
});