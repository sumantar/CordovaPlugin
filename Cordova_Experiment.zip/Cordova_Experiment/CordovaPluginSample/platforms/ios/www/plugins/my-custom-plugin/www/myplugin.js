cordova.define("my-custom-plugin.myplugin", function(require, exports, module) { /*global cordova, module*/

var MyPluginCls = function() {};
               
MyPluginCls.prototype.greet = function (name) {
               cordova.exec(myPluginCls.mySuccess, myPluginCls.myFailure, "MyPlugin", "greet", [name]);
};
    
MyPluginCls.prototype.mySuccess = function(message) {
    alert(message);
}
               
MyPluginCls.prototype.myFailure = function() {
	alert("Error calling Hello Plugin");
}
               
var myPluginCls = new MyPluginCls();
module.exports = myPluginCls;
               
/*
 module.exports = {
    greet: function (name, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, "MyPlugin", "greet", [name]);
    }
 };
 */
});
